import java.io.*;

/**
 * Esta tarefa tem a possibilidade de
 * trabalhar com o mesmo robot ou com um robot diferente das outras tarefas.
 * A manipulação do ficheiro deve obrigatoriamente ser efetuada com as classes de
 * InputStream, Reader, OutputStream e Writer do java.io.
 */
public class Gravador extends Tarefa {
    private DadosGUI dadosGUI;

    // gravação
    private boolean gravar; // trocar para volatile?
    private String caminhoGravar;
    private OutputStream os;
    private Writer writer;

    // reprodução
    private boolean reproduzir; // trocar para volatile?
    private String caminhoReproduzir;

    public Gravador(DadosGUI dadosGUI) {
        this.dadosGUI = dadosGUI;
        gravar = false;
        reproduzir = false;
    }

    public synchronized boolean isGravar() {
        return gravar;
    }

    public synchronized void iniciarGravar(String caminhoFicheiro) {
        // se estiver a gravar
        if (gravar) {
            dadosGUI.getGui().print("Gravador: Gravação ativa");
            return;
        }
        // tratamento de erros
        if (caminhoFicheiro == null || caminhoFicheiro.trim().isEmpty()) {
            dadosGUI.getGui().print("Gravador: Caminho do ficheiro inválido");
            return;
        }

        try {
            caminhoGravar = caminhoFicheiro;

            os = new FileOutputStream(caminhoGravar, false);
            writer = new OutputStreamWriter(os, "UTF-8");
            gravar = true;
            dadosGUI.getGui().print("Gravador: gravação iniciada em " + caminhoGravar);
        } catch (IOException e) {
            dadosGUI.getGui().print("Gravador: erro a iniciar gravação: " + e.getMessage());
            fecharWritter();
        }
    }

    public synchronized void pararGravacao() {
        if (!gravar) {
            dadosGUI.getGui().print("Gravador: não está a gravar");
            return;
        }
        fecharWritter();
        gravar = false;
        dadosGUI.getGui().print("Gravador: gravação acabada");


    }

    /**
     * ação mesmo de gravar
     * recebe um comando, testa para ver se é null
     * convertemos o comando para string com o método auxiliar
     * "\n" a cada linha para separar os comandos como deve de ser
     */
    public void gravarComando(Comando comando) {
        Writer w;
        synchronized (this) {
            w = this.writer;
        }
        if (!gravar || w == null || comando == null) return;

        try {
            String linha = encode(comando);
            synchronized (this) {
                if (writer != null) {
                    writer.write(linha);
                    writer.write("\n");
                    writer.flush();
                }
            }
        } catch (IOException e) {
            dadosGUI.getGui().print("Gravador: erro a escrever comando: " + e.getMessage());
        }
    }

    public synchronized void reproduzir(String caminhoFicheiro) {
        if (reproduzir) {
            dadosGUI.getGui().print("Gravador: já está a reproduzir");
            return;
        }

        if (caminhoFicheiro == null || caminhoFicheiro.trim().isEmpty()) {
            dadosGUI.getGui().print("Gravador: caminho do ficheiro inválido");
            return;
        }

        // ativar tarefa para trabalhar
        this.caminhoReproduzir = caminhoFicheiro;
        this.reproduzir = true;
        ativar();
    }

    /**
     * Método auxiliar para de comando para texto
     */
    private String encode(Comando comando) {
        switch (comando.getIdentificador()) {
            case Comando.ID_RETA:
                return "RETA " + comando.getArg1();
            case Comando.ID_DIREITA:
                return "DIREITA " + comando.getArg1() + " " + comando.getArg2();
            case Comando.ID_ESQUERDA:
                return "ESQUERDA " + comando.getArg1() + " " + comando.getArg2();
            case Comando.ID_PARAR:
                return "PARAR " + (comando.getArg1() != 0 ? 1 : 0);
            default:
                return "desconhecido " + comando.toString();
        }
    }

    /**
     * Método auxiliar para de texto para comando
     */
    private Comando decode(String linha) {
        try {
            String[] comando = linha.split("\\s+"); // vamos separar um array de strings
            // Ex: RETA 10 -> ["RETA", "10"]
            String op = comando[0].toUpperCase();
            switch (op) {
                case "RETA":
                    return new Comando(Comando.ID_RETA, Integer.parseInt(comando[1]));
                case "DIREITA":
                    return new Comando(Comando.ID_DIREITA, Integer.parseInt(comando[1]), Integer.parseInt(comando[2]));
                case "ESQUERDA":
                    return new Comando(Comando.ID_ESQUERDA, Integer.parseInt(comando[1]), Integer.parseInt(comando[2]));
                case "PARAR":
                    return new Comando(Comando.ID_PARAR, Integer.parseInt(comando[1]));
                default:
                    return null;
            }
        } catch (Exception e) {
            return null;
        }
    }


    @Override
    void trabalharAtividade() throws InterruptedException {
        // executar SÓ se estiver em modo de reprodução
        if (!reproduzir) {
            estado = Estados.DORMIR;
            return;
        }

        // tratamento de erros
        if (!dadosGUI.isOnOff()) {
            dadosGUI.getGui().print("Gravador: ligue o robot primeiro");
            reproduzir = false;
            estado = Estados.DORMIR;
            return;
        }

        dadosGUI.getGui().print("Gravador: iniciar reprodução de " + caminhoReproduzir);

        try (InputStream is = new FileInputStream(caminhoReproduzir);
             Reader ir = new InputStreamReader(is, "UTF-8");
             BufferedReader br = new BufferedReader(ir)) {

            try {
                dadosGUI.getRobot().entrar();
                dadosGUI.getGui().print("--------------------");
                dadosGUI.getGui().print("Gravador: Semáforo adquirido");

                String linha;
                while ((linha = br.readLine()) != null && estado == Estados.TRABALHAR) {
                    linha = linha.trim();
                    if (linha.isEmpty()) continue;

                    Comando comando = decode(linha);
                    if (comando == null) {
                        dadosGUI.getGui().print("Gravador: linha inválida: " + linha);
                        continue;
                    }
                    esperarComando(comando);
                }

                // no fim parar de forma não imediata para acabar a sequência
                dadosGUI.getGui().print("Gravador: Parar(false)");
                dadosGUI.getRobot().Parar(false);
            } finally {
                // liberar semaforo
                dadosGUI.getRobot().sair();
                dadosGUI.getGui().print("Gravador: Semáforo liberado");
                dadosGUI.getGui().print("--------------------");
            }
            dadosGUI.getGui().print("Gravador: reprodução concluída");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            dadosGUI.getGui().print("Gravador: reprodução interrompida");
        } catch (IOException e) {
            dadosGUI.getGui().print("Gravador: erro ao ler ficheiro: " + e.getMessage());
        } finally {
            reproduzir = false;
            estado = Estados.DORMIR;
        }
    }

    private void esperarComando(Comando comando) throws InterruptedException {
        long espera = comando.executarComandos(dadosGUI.getRobot());

        dadosGUI.getGui().print("Gravador: " + comando.toString());
        if (espera > 0) {
            dadosGUI.getGui().print("Gravador: espera " + espera + " ms");
            Thread.sleep(espera);
        }
    }

    private synchronized void fecharWritter() {
        try {
            if (writer != null) writer.close();
        } catch (IOException e) {

        } finally {
            writer = null;
        }

        try {
            if (os != null) os.close();
        } catch (IOException e) {
        } finally {
            os = null;
        }
    }
}
