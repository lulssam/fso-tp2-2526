import java.util.ArrayList;
import java.util.Random;

/**
 * RETA: a distância deve ter um valor aleatório entre 10cm e 50cm
 * <br>
 * CURVAS: o raio deve ter um valor aleatório entre 10 e 30 cm e o angulo um valor aleatório entre 20 e 90 graus
 */
public class MovAleatorios extends Tarefa {

    private final DadosGUI dadosGUI;
    private final Random random = new Random();
    private ArrayList comandos;

    public MovAleatorios(DadosGUI dadosGUI) {
        this.dadosGUI = dadosGUI;
        comandos = new ArrayList<>();
    }

    @Override
    void trabalharAtividade() throws InterruptedException {
        int num;
        try {
            num =  dadosGUI.getNumMovimentos(); // obter valor do spinner
        } catch (Exception e) {
            num = 0;
        }
        // tratamento de erros
        if (num <= 0) {
            dadosGUI.getGui().print("Movimentos Aleatorios: numero inválido (" + num + ")");
            estado = Estados.DORMIR;
            return;
        }

        // verificação para cada LOOP
        if (Thread.interrupted()) {
            dadosGUI.getGui().print("Movimentos Aleatorios: Interrompido");
            estado = Estados.DORMIR;
            return;
        }

        try {
            dadosGUI.getGui().print("Movimentos Aleatorios: iniciando");
            dadosGUI.getRobot().entrar();
            dadosGUI.getGui().print("---------------------------------");
            dadosGUI.getGui().print("Movimentos Aleatorios: Semaforo adquirido");
            for (int i = 0; i < num && estado == Estados.TRABALHAR; i++) {

                // verificação a cada ITERAÇÃO
                if (Thread.interrupted()) {
                    dadosGUI.getGui().print("Movimentos Aleatorios: Interrompido");
                    return;
                }


                int movimento = random.nextInt(3); // reta = 0, dir = 1, esq = 2
                switch (movimento) {
                    case 0: {
                        // RETA
                        int distancia = randoms(10, 50);
                        dadosGUI.getGui().print(i + 1 + ": Comando Aleatório: Reta: " + distancia + " cm");
                        dadosGUI.getRobot().Reta(distancia);
                        dadosGUI.registrarComandos(new Comando(Comando.ID_RETA, distancia));
                        // esperar tempo total de executação
                        long tempo = TempoMovimento.tempoReta(distancia);
                        dadosGUI.getGui().print("Espera: " + tempo + " ms");
                        Thread.sleep(tempo);
                        break;
                    }

                    case 1: {
                        // DIREITA
                        int raio = randoms(10, 30);
                        int angulo = randoms(20, 90);
                        dadosGUI.getGui().print(i + 1 + ": Comando Aleatório: Curvar Direita Raio: " + raio + " e Angulo: " + angulo);
                        dadosGUI.getRobot().CurvarDireita(raio, angulo);
                        dadosGUI.registrarComandos(new Comando(Comando.ID_DIREITA, raio, angulo));
                        long tempo = TempoMovimento.tempoCurvar(raio, angulo);
                        dadosGUI.getGui().print("Espera: " + tempo + " ms");
                        Thread.sleep(tempo);
                        break;
                    }
                    case 2: {
                        // ESQUERDA
                        int raio = randoms(10, 30);
                        int angulo = randoms(20, 90);
                        dadosGUI.getGui().print(i + 1 + ": Comando Aleatório: Curvar Esquerda Raio: " + raio + " e Angulo: " + angulo);
                        dadosGUI.getRobot().CurvarEsquerda(raio, angulo);
                        dadosGUI.registrarComandos(new Comando(Comando.ID_ESQUERDA, raio, angulo));
                        long tempo = TempoMovimento.tempoCurvar(raio, angulo);
                        dadosGUI.getGui().print("Espera: " + tempo + " ms");
                        Thread.sleep(tempo);
                        break;
                    }
                }
                comandos.add(movimento);
            }
            dadosGUI.getGui().print("Comando Aleatório: Parar(false)");
            dadosGUI.getRobot().Parar(false);
            dadosGUI.registrarComandos(new Comando(Comando.ID_PARAR, 0));

        } finally {
            dadosGUI.getRobot().sair();
            dadosGUI.getGui().print("Movimentos Aleatorios: Semaforo Liberado");
            dadosGUI.getGui().print("---------------------------------");
        }
    }

    private int randoms(int min, int max) {
        return random.nextInt((max - min) + 1) + min;
    }
}