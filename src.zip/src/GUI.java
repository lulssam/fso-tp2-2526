import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GUI extends JFrame {

    private static final long serialVersionUID = 1L;
    private DadosGUI dadosGUI;

    private JPanel contentPane;
    private JTextField raioField;
    private JTextField anguloField;
    private JTextField distanciaField;
    private JTextField robotField;
    private JTextArea consolaTextArea;

    private JButton frenteBtn;
    private JButton trasBtn;
    private JButton pararBtn;
    private JButton esquerdaBtn;
    private JButton direitaBtn;
    private JSpinner numSpinner;
    private JRadioButton movAleatoriosRadioBtn;
    private JCheckBox tipoRobotChkBox;
    private JPanel gravadorPanel;
    private JTextField ficheiroField;
    private JButton browseBtn;
    private JButton gravarBtn;
    private JButton reproduzirBtn;
    private JButton limparBtn;
    private JCheckBox imprimirChkBox;

    /**
     * Create the frame.
     */
    public GUI() {

        // Iniciar Janela
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 467, 610);
        contentPane = new JPanel();
        contentPane.setBackground(new Color(254, 255, 255));
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel raioLabel = new JLabel("Raio");
        raioLabel.setBounds(6, 6, 27, 16);
        contentPane.add(raioLabel);

        raioField = new JTextField();
        raioField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                // Meter raio
                dadosGUI.setRaio(Integer.parseInt(raioField.getText()));
            }
        });
        raioField.setBounds(45, 1, 33, 26);
        contentPane.add(raioField);
        raioField.setColumns(10);

        JLabel anguloLabel = new JLabel("Ângulo");
        anguloLabel.setBounds(90, 6, 45, 16);
        contentPane.add(anguloLabel);

        anguloField = new JTextField();
        anguloField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                // Meter ângulo
                dadosGUI.setAngulo(Integer.parseInt(anguloField.getText()));
            }
        });
        anguloField.setBounds(147, 1, 33, 26);
        contentPane.add(anguloField);
        anguloField.setColumns(10);

        JLabel distanciaLabel = new JLabel("Distância");
        distanciaLabel.setBounds(190, 6, 61, 16);
        contentPane.add(distanciaLabel);

        distanciaField = new JTextField();
        distanciaField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                // Meter distância
                dadosGUI.setDistancia(Integer.parseInt(distanciaField.getText()));
            }
        });
        distanciaField.setColumns(10);
        distanciaField.setBounds(263, 1, 33, 26);
        contentPane.add(distanciaField);

        JLabel robotLabel = new JLabel("Robot");
        robotLabel.setBounds(339, 6, 45, 16);
        contentPane.add(robotLabel);

        robotField = new JTextField();
        robotField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                // Meter nome do Robot
                dadosGUI.setNomeRobot(robotField.getText());
            }
        });
        robotField.setColumns(10);
        robotField.setBounds(387, 1, 33, 26);
        contentPane.add(robotField);

        JCheckBox ligarChkBox = new JCheckBox("Ligar");
        ligarChkBox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                // Ligar/Desligar Robot
                if (ligarChkBox.isSelected()) { // se selecionarmos o botão
                    dadosGUI.getRobot().OpenEV3(dadosGUI.getNomeRobot());  // se conseguirmos obter o nome do robot e ligar
                    dadosGUI.setOnOff(true);
                    dadosGUI.getRobot().start();
                    print("Sucesso na abertura das Streams");
                } else {
                    // se desligar, parar a tarefa de mov aleatorios se estiver ativa
                    if (movAleatoriosRadioBtn.isSelected()) {
                        movAleatoriosRadioBtn.setSelected(false);
                        if (dadosGUI.getMovAleatorios() != null) {
                            dadosGUI.getMovAleatorios().desativar();
                        }
                    }
                    dadosGUI.getRobot().CloseEV3();
                    dadosGUI.setOnOff(false);
                    dadosGUI.getRobot().stop();
                    ligarChkBox.setSelected(false);
                    print("Conexão encerrada");
                }
            }
        });
        ligarChkBox.setBounds(322, 34, 73, 23);
        contentPane.add(ligarChkBox);

        frenteBtn = new JButton("FRENTE");
        frenteBtn.setBounds(156, 55, 117, 29);
        frenteBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Runnable frenteTarefa = new Runnable() {
                    @Override
                    public void run() {
                        frenteAction();
                    }
                };
                new Thread(frenteTarefa).start();
            }
        });
        contentPane.add(frenteBtn);

        pararBtn = new JButton("PARAR");
        pararBtn.setBounds(156, 84, 117, 29);
        pararBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dadosGUI.getRobot().Parar(true);
                dadosGUI.registrarComandos(new Comando(Comando.ID_PARAR, 1));
                print("Comando enviado: Parar (imediato)");
            }
        });
        contentPane.add(pararBtn);

        trasBtn = new JButton("TRÁS");
        trasBtn.setBounds(156, 114, 117, 29);
        trasBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Runnable trasTarefa = new Runnable() {
                    @Override
                    public void run() {
                        trasAction();
                    }
                };
                new Thread(trasTarefa).start();
            }
        });
        contentPane.add(trasBtn);

        direitaBtn = new JButton("DIREITA");
        direitaBtn.setBounds(267, 84, 117, 29);
        direitaBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Runnable direitaTarefa = new Runnable() {
                    @Override
                    public void run() {
                        direitaAction();
                    }
                };
                new Thread(direitaTarefa).start();
            }
        });
        contentPane.add(direitaBtn);

        esquerdaBtn = new JButton("ESQUERDA");
        esquerdaBtn.setBounds(45, 84, 117, 29);
        esquerdaBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Runnable esquerdaTarefa = new Runnable() {
                    @Override
                    public void run() {
                        esquerdaAction();
                    }
                };
                new Thread(esquerdaTarefa).start();
            }
        });
        contentPane.add(esquerdaBtn);

        tipoRobotChkBox = new JCheckBox("Simulado/Real");
        tipoRobotChkBox.setBounds(10, 155, 115, 23);
        tipoRobotChkBox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (tipoRobotChkBox.isSelected()) {
                    print("Modo Selecionado: Robot Simulado");
                    dadosGUI.getRobot().setRobot(new RobotSimulado());
                } else {
                    print("Modo Selecionado: Robot Real");
                    dadosGUI.getRobot().setRobot(new CRobotLegoEV3());
                }
            }
        });
        contentPane.add(tipoRobotChkBox);

        numSpinner = new JSpinner();
        numSpinner.setBounds(191, 155, 34, 26);
        contentPane.add(numSpinner);

        JLabel numeroLabel = new JLabel("Número");
        numeroLabel.setBounds(135, 160, 61, 16);
        contentPane.add(numeroLabel);

        movAleatoriosRadioBtn = new JRadioButton("Movimentos Aleatórios");
        movAleatoriosRadioBtn.setBounds(277, 134, 182, 16);
        movAleatoriosRadioBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (movAleatoriosRadioBtn.isSelected()) {
                    if (!dadosGUI.isOnOff()) {
                        print("Ligar robot primeiro!");
                        movAleatoriosRadioBtn.setSelected(false);
                    }
                    print("Movimentos Aleatórios Selecionado");
                    dadosGUI.getMovAleatorios().ativar();
                } else {
                    print("Movimentos Aleatórios Desativado");
                    dadosGUI.getMovAleatorios().desativar();
                }
            }
        });
        contentPane.add(movAleatoriosRadioBtn);

        gravadorPanel = new JPanel();
        gravadorPanel.setOpaque(false);
        gravadorPanel.setBorder(BorderFactory.createTitledBorder("Gravador"));
        gravadorPanel.setBounds(6, 190, 455, 80);
        gravadorPanel.setLayout(null);
        contentPane.add(gravadorPanel);

        JLabel ficheiroLabel = new JLabel("Ficheiro");
        ficheiroLabel.setBounds(10, 30, 50, 16);
        gravadorPanel.add(ficheiroLabel);

        ficheiroField = new JTextField();
        ficheiroField.setBounds(65, 25, 300, 26);
        gravadorPanel.add(ficheiroField);
        ficheiroField.setColumns(10);

        browseBtn = new JButton("...");
        browseBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JFileChooser fileChooser = new JFileChooser();
                int result = fileChooser.showOpenDialog(GUI.this);
                if (result == JFileChooser.APPROVE_OPTION) {
                    ficheiroField.setText(fileChooser.getSelectedFile().getAbsolutePath());
                    print("Ficheiro selecionado: " + ficheiroField.getText());
                }
            }
        });
        browseBtn.setBounds(370, 24, 45, 29);
        gravadorPanel.add(browseBtn);

        gravarBtn = new JButton("Gravar");
        gravarBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (!dadosGUI.isOnOff()) {
                    print("Ligar o robot primeiro");
                    return;
                }
                String caminho = ficheiroField.getText() != null ? ficheiroField.getText().trim() : "";
                if (caminho.isEmpty()) {
                    print("Selecione um ficheiro para gravar primeiro");
                    return;
                }

                if (!dadosGUI.getGravador().isGravar()) {
                    dadosGUI.getGravador().iniciarGravar(caminho);
                    gravarBtn.setText("Parar Gravação");
                } else {
                    dadosGUI.getGravador().pararGravacao();
                    gravarBtn.setText("Gravar");
                }
            }
        });
        gravarBtn.setBounds(100, 50, 117, 29);
        gravadorPanel.add(gravarBtn);

        reproduzirBtn = new JButton("Reproduzir");
        reproduzirBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (!dadosGUI.isOnOff()) {
                    print("Ligar o robot");
                }

                String caminho = ficheiroField.getText() != null ? ficheiroField.getText().trim() : "";
                if (caminho.isEmpty()) {
                    print("Selecione um ficheiro para reproduzir primeiro");
                    return;
                }

                // se estiver a gravar, para primeiro
                if (dadosGUI.getGravador().isGravar()) {
                    dadosGUI.getGravador().pararGravacao();
                    gravarBtn.setText("Gravar");
                }
                dadosGUI.getGravador().reproduzir(caminho);
                print("Reproduzir");
            }
        });
        reproduzirBtn.setBounds(230, 50, 117, 29);
        gravadorPanel.add(reproduzirBtn);

        JLabel consolaLabel = new JLabel("Consola");
        consolaLabel.setBounds(6, 280, 61, 16);
        contentPane.add(consolaLabel);

        JScrollPane consolaScrollPane = new JScrollPane();
        consolaScrollPane.setBounds(6, 300, 455, 230);
        contentPane.add(consolaScrollPane);
        consolaTextArea = new JTextArea();
        consolaScrollPane.setViewportView(consolaTextArea);


        JRadioButton evitarRadioBtn = new JRadioButton("Evitar Obstáculos");
        evitarRadioBtn.setBounds(277, 162, 182, 16);
        evitarRadioBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (evitarRadioBtn.isSelected()) {
                    if (!dadosGUI.isOnOff()) {
                        print("Ligar robot primeiro!");
                        evitarRadioBtn.setSelected(false);
                    }
                    print("Evitar Objetos Selecionado");
                    dadosGUI.getEvitarObstaculos().ativar();
                } else {
                    print("Evitar Objetos Desativado");
                    dadosGUI.getEvitarObstaculos().desativar();
                }
            }
        });
        contentPane.add(evitarRadioBtn);

        limparBtn = new JButton("Limpar");
        limparBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                consolaTextArea.setText(null); // Limpa a consola
            }
        });
        limparBtn.setBounds(120, 540, 117, 29);
        contentPane.add(limparBtn);

        imprimirChkBox = new JCheckBox("Imprimir");
        imprimirChkBox.setSelected(true);
        imprimirChkBox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (imprimirChkBox.isSelected()) {
                    print("Impressão na consola ATIVADA.");
                }
            }
        });
        imprimirChkBox.setBounds(250, 542, 100, 23);
        contentPane.add(imprimirChkBox);

        setVisible(true);
    }

    public JSpinner getNumSpinner() {
        return numSpinner;
    }

    public void setDadosGUI(DadosGUI dadosGUI) {
        this.dadosGUI = dadosGUI;
        // valores pre definidos gui
        raioField.setText(Integer.toString(dadosGUI.getRaio()));
        anguloField.setText(Integer.toString(dadosGUI.getAngulo()));
        distanciaField.setText(Integer.toString(dadosGUI.getDistancia()));
        robotField.setText(dadosGUI.getNomeRobot());
    }

    public void print(String s) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                if (imprimirChkBox == null || imprimirChkBox.isSelected()) {
                    consolaTextArea.append(s + "\n");
                    consolaTextArea.setCaretPosition(consolaTextArea.getDocument().getLength());
                }
            }
        });

    }

    private void frenteAction() {
        try {
            dadosGUI.getRobot().entrar();
            dadosGUI.getRobot().Reta(dadosGUI.getDistancia());
            dadosGUI.registrarComandos(new Comando(Comando.ID_RETA, dadosGUI.getDistancia()));
            print("Comando enviado: Frente com distância " + dadosGUI.getDistancia());
            print("Espera: " + TempoMovimento.tempoReta(dadosGUI.getDistancia()));
            // TODO confirmar com stor
            dadosGUI.registrarComandos(new Comando(Comando.ID_PARAR, 0));
            dadosGUI.getRobot().Parar(false);
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
        } finally {
            dadosGUI.getRobot().sair();
        }
    }

    private void trasAction() {
        try {
            dadosGUI.getRobot().entrar();
            dadosGUI.getRobot().Reta(dadosGUI.getDistancia() * -1);
            dadosGUI.registrarComandos(new Comando(Comando.ID_RETA, dadosGUI.getDistancia() * -1));
            print("Comando enviado: Trás com distância: " + dadosGUI.getDistancia());
            print("Espera: " + TempoMovimento.tempoReta(dadosGUI.getDistancia()));
            dadosGUI.registrarComandos(new Comando(Comando.ID_PARAR, 0));
            dadosGUI.getRobot().Parar(false);
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
        } finally {
            dadosGUI.getRobot().sair();
        }
    }

    private void direitaAction() {
        try {
            dadosGUI.getRobot().entrar();
            dadosGUI.getRobot().CurvarDireita(dadosGUI.getRaio(), dadosGUI.getAngulo());
            dadosGUI.registrarComandos(new Comando(Comando.ID_DIREITA, dadosGUI.getRaio(), dadosGUI.getAngulo()));
            print("Comando enviado: Curvar à Direita com ângulo " + dadosGUI.getAngulo() + " e raio " + dadosGUI.getRaio());
            print("Espera: " + TempoMovimento.tempoCurvar(dadosGUI.getRaio(), dadosGUI.getAngulo()) + " ms");
            dadosGUI.registrarComandos(new Comando(Comando.ID_PARAR, 0));
            dadosGUI.getRobot().Parar(false);
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
        } finally {
            dadosGUI.getRobot().sair();
        }
    }

    private void esquerdaAction() {
        try {
            dadosGUI.getRobot().entrar();
            dadosGUI.getRobot().CurvarEsquerda(dadosGUI.getRaio(), dadosGUI.getAngulo());
            dadosGUI.registrarComandos(new Comando(Comando.ID_ESQUERDA, dadosGUI.getRaio(), dadosGUI.getAngulo()));
            print("Comando enviado: Curvar à Esquerda com ângulo " + dadosGUI.getAngulo() + " e raio " + dadosGUI.getRaio());
            print("Espera: " + TempoMovimento.tempoCurvar(dadosGUI.getRaio(), dadosGUI.getAngulo()) + " ms");
            dadosGUI.registrarComandos(new Comando(Comando.ID_PARAR, 0));
            dadosGUI.getRobot().Parar(false);
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
        } finally {
            dadosGUI.getRobot().sair();
        }
    }
}