import java.util.Random;

/**
 * A tarefa “Evitar Obstáculo” deve de estar a testar o sensor de toque de 50 em 50 ms, e
 * quando este ficar ativo deve imediatamente parar o robot, depois fazer recuar o robot de 20
 * cm, e depois fazer uma curva à esquerda ou à direita (com escolha aleatória) de 90 graus.
 * Durante estas ações nem o utilizador nem as outras tarefas devem poder movimentar o robot.
 */
public class EvitarObstaculos extends Tarefa {
    private DadosGUI dadosGUI;
    private MyRobotSync robot;
    private Random random;

    public EvitarObstaculos(DadosGUI dadosGUI) {
        this.dadosGUI = dadosGUI;
        random = new Random();
        robot = dadosGUI.getRobot();
    }

    @Override
    void trabalharAtividade() throws InterruptedException {
        int toque = robot.SensorToque(RobotLegoEV3.S_1);
        switch (toque) {
            case 0:
                break;
            case 1:
                dadosGUI.getRobot().Parar(true); // parar imediatamente
                dadosGUI.getGui().print("Evitar Obstáculos: Obstáculo Detectado");
                try {
                    // se os mov aleatorios estiverem ATIVOS e a FUNCIONAR
                    if (dadosGUI.getMovAleatorios() != null && dadosGUI.getMovAleatorios().isAlive()) {
                        dadosGUI.getGui().print("Evitar Obstáculos: Movimentos Aleatórios");
                        dadosGUI.getMovAleatorios().interrupt(); // interromper
                    }

                    dadosGUI.getGui().print("Evitar Obstáculos: Iniciados");
                    dadosGUI.getRobot().entrar();
                    dadosGUI.getGui().print("---------------------------------");
                    dadosGUI.getGui().print("Evitar Obstáculos: Semáforo adquirido");
                    Thread.sleep(TempoMovimento.getTempoComunicacao());
                    dadosGUI.getGui().print("Evitar Obstaculos: Parar.");

                    // reta
                    int distancia = -20;
                    dadosGUI.getRobot().Reta(distancia);
                    dadosGUI.registrarComandos(new Comando(Comando.ID_RETA, distancia));
                    dadosGUI.getGui().print("Evitar Obstáculos: Reta com distância: " + distancia);
                    Thread.sleep(TempoMovimento.tempoReta(distancia));

                    int escolha = random();

                    switch (escolha) {
                        // esquerda
                        case 0:
                            dadosGUI.getRobot().CurvarEsquerda(0, 90);
                            dadosGUI.registrarComandos(new Comando(Comando.ID_ESQUERDA, 0, 90));
                            dadosGUI.getGui().print("Evitar Obstáculos: Curva Esquerda com raio: 0, e angulo: 90º. ");
                            Thread.sleep(TempoMovimento.tempoCurvar(0, 90));

                            break;
                        case 1:
                            dadosGUI.getRobot().CurvarDireita(0, 90);
                            dadosGUI.registrarComandos(new Comando(Comando.ID_DIREITA, 0, 90));
                            dadosGUI.getGui().print("Evitar Obstáculos: Curva Direita com raio: 0, e angulo: 90º. ");
                            Thread.sleep(TempoMovimento.tempoCurvar(0, 90));

                            break;

                    }
                    break;

                } finally {
                    dadosGUI.getRobot().Parar(false);
                    dadosGUI.getRobot().sair();
                    dadosGUI.getGui().print("Evitar Obstáculos: Semaforo Liberado");
                    dadosGUI.getGui().print("---------------------------------");
                }
        }
        Thread.sleep(50);
    }

    private int random() {
        return random.nextInt(2);
    }

}