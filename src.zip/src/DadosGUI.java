import java.util.ArrayList;

public class DadosGUI {
    private GUI gui;
    // ROBOT
    private MyRobotSync robot;
    private String nomeRobot;
    private int raio, angulo, distancia;
    private boolean onOff;

    private int numMovimentos;
    private boolean imprimir;
    private ArrayList<String> texto;
    private DadosGUI dadosGUI;
    private EvitarObstaculos evitarObstaculos;
    private MovAleatorios movAleatorios;
    private Gravador gravador;

    public DadosGUI(GUI gui) {
        this.gui = gui;
        texto = new ArrayList<>();
        raio = 20;
        angulo = 90;
        distancia = 33;
        onOff = false;
        robot = new MyRobotSync();

        // tarefa mov aleatorios
        movAleatorios = new MovAleatorios(this);
        movAleatorios.start();

        // tarefa evitar obstaculos
        evitarObstaculos = new EvitarObstaculos(this);
        evitarObstaculos.start();

        // tarefa gravador
        gravador = new Gravador(this);
        gravador.start();
    }

    public String getNomeRobot() {
        return nomeRobot;
    }

    public void setNomeRobot(String nomeRobot) {
        this.nomeRobot = nomeRobot;
    }

    public GUI getGui() {
        return gui;
    }

    public void setGui(GUI gui) {
        this.gui = gui;
    }

    public ArrayList<String> getTexto() {
        return texto;
    }

    public void setTexto(ArrayList<String> texto) {
        this.texto = texto;
    }

    public int getRaio() {
        return raio;
    }

    public void setRaio(int raio) {
        this.raio = raio;
    }

    public int getAngulo() {
        return angulo;
    }

    public void setAngulo(int angulo) {
        this.angulo = angulo;
    }

    public int getDistancia() {
        return distancia;
    }

    public void setDistancia(int distancia) {
        this.distancia = distancia;
    }

    public boolean isOnOff() {
        return onOff;
    }

    public void setOnOff(boolean onOff) {
        this.onOff = onOff;
    }

    public MyRobotSync getRobot() {
        return robot;
    }

    public void setRobot(MyRobotSync robot) {
        this.robot = robot;
    }

    public MovAleatorios getMovAleatorios() {
        return movAleatorios;
    }

    public EvitarObstaculos getEvitarObstaculos() {
        return evitarObstaculos;
    }

    public Gravador getGravador() {
        return gravador;
    }

    public void setGravador(Gravador gravador) {
        this.gravador = gravador;
    }

    public int getNumMovimentos() {
        return (int) getGui().getNumSpinner().getValue();
    }

    public void setNumMovimentos(int numMovimentos) {
        this.numMovimentos = numMovimentos;
    }

    public boolean isImprimir() {
        return imprimir;
    }

    public void setImprimir(boolean imprimir) {
        this.imprimir = imprimir;
    }

    /**
     * Método para encaminhar os comandos para o gravdor quando acionarmos o modo
     */
    public void registrarComandos(Comando c) {
        if (gravador != null) {
            gravador.gravarComando(c);
        }
    }

}