public class SyncTarefas {

}
