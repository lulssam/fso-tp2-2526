import javax.swing.*;

public class App implements Runnable {
    private GUI gui;
    private DadosGUI dadosGUI;

    public App() {
        SwingUtilities.invokeLater(this);
        gui = new GUI();
        dadosGUI = new DadosGUI(gui);
        gui.setDadosGUI(dadosGUI);
        gui.setVisible(true);
    }

    public static void main(String[] args) {
        App app = new App();
        new Thread(app).start();
    }

    public void run() {

    }
}

